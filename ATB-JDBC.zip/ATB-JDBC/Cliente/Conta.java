package Cliente;
import java.security.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Conta {
    private int id;
    private String numeroConta;
    private float saldo;
    private String tipo;
    private int agenciaId;
    private String senha;
    private List<Cliente> clientes = new ArrayList<>();

    public Conta(int id, String numeroConta, float saldo, String tipo, int agenciaId, String senha) {
        this.id = id;
        this.numeroConta = numeroConta;
        this.saldo = saldo;
        this.tipo = tipo;
        this.agenciaId = agenciaId;
        this.senha = hash(senha);
    }

    public void adicionarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void removerCliente(Cliente cliente) {
        clientes.remove(cliente);
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    private String hash(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(senha.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao criar hash da senha", e);
        }
    }
}
