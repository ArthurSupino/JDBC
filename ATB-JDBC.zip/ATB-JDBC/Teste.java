
public class Teste 
{
    public static void main(String[] args) 
    {
    }   
}
