

/*import Bank.Agencia;
import Bank.Banco;
import Cliente.Cliente;
import Cliente.Conta;
import Conexao.FalhaConexaoException;
import DAOT.AgenciaDAO;
import DAOT.BancoDAO;
import DAOT.ClienteDAO;
import DAOT.ContaDAO;

public class Teste {
    public static void main(String[] args) {
        try {

            Banco banco = Banco.getInstancia(1, "Banco do Povo", "Av. Principal, 100", "1234-5678");
            BancoDAO bancoDAO = new BancoDAO();
            AgenciaDAO agenciaDAO = new AgenciaDAO();
            ClienteDAO clienteDAO = new ClienteDAO();
            ContaDAO contaDAO = new ContaDAO();

            
            bancoDAO.inserirBanco(banco);
            System.out.println("Banco criado: " + banco);

            Agencia agencia = new Agencia(0, "Rua Secundária, 200", "8765-4321", "AG123");
            agenciaDAO.inserirAgencia(agencia);
            System.out.println("Agência criada: " + agencia);

            Cliente cliente = new Cliente(0, "João Silva", "12345678900", "Rua Exemplo, 300", "9876-5432", "joao@email.com");
            clienteDAO.inserirCliente(cliente);
            System.out.println("Cliente criado: " + cliente);

            Conta conta = new Conta(0, "12345-6", 500.00f, "Corrente", agencia.getId_agencia(), "senha123");
            contaDAO.inserirConta(conta);
          
            System.out.println("Conexão fechada com sucesso!");

        } catch (FalhaConexaoException e) {
            System.err.println("Erro na conexão: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestDriver {
    public static void main(String[] args) {
        // URL de conexão com o banco de dados
        String url = "jdbc:mysql://172.17.0.3:3306/SistemaBancario";
        String usuario = "root";
        String senha = "s";

        try {
            // Carregar o driver JDBC do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver JDBC MySQL carregado com sucesso.");

            // Estabelecer a conexão
            Connection conn = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexão estabelecida com sucesso!");

            // Fechar a conexão
            conn.close();
        } catch (ClassNotFoundException e) {
            System.err.println("Falha ao carregar o Driver do JDBC MySQL: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Erro na conexão: " + e.getMessage());
        }
    }
}





