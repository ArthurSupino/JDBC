package DAOT;

/*import Cliente.Cliente;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ClienteDAO {
    public void inserirCliente(Cliente cliente) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Cliente (id, nome, cpf, endereco, telefone, email) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, cliente.getId());
                stmt.setString(2, cliente.getNome());
                stmt.setString(3, cliente.getCpf());
                stmt.setString(4, cliente.getEndereco());
                stmt.setString(5, cliente.getTelefone());
                stmt.setString(6, cliente.getEmail());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Cliente: " + e.getMessage());
        }
    }
}*/

