package DAOT;

/*import Bank.Banco;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BancoDAO {
    public void inserirBanco(Banco banco) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Banco (id_banco, nome, endereco, telefone) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, banco.getId_banco());
                stmt.setString(2, banco.getNome());
                stmt.setString(3, banco.getEndereco());
                stmt.setString(4, banco.getTelefone());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Banco: " + e.getMessage());
        }
    }

    // Métodos para atualizar, buscar e excluir conforme necessário 
}*/
