package DAOT;

/*import Cliente.Conta;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ContaDAO {
    public void inserirConta(Conta conta) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Conta (id, numero_conta, saldo, tipo, agencia_id, senha) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, conta.getId());
                stmt.setString(2, conta.getNumeroConta());
                stmt.setFloat(3, conta.getSaldo());
                stmt.setString(4, conta.getTipo());
                stmt.setInt(5, conta.getAgenciaId());
                stmt.setString(6, conta.getSenha());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Conta: " + e.getMessage());
        }
    }
}*/