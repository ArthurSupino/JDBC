package DAOT;

import Cliente.Conta;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ContaDAO {
    public void inserirConta(Conta conta) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Conta (id, numero_conta, saldo, tipo, senha) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, conta.getId());
                stmt.setString(2, conta.getNumeroConta());
                stmt.setFloat(3, conta.getSaldo());
                stmt.setString(4, conta.getTipo());
                stmt.setString(5, conta.getSenha());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Conta: " + e.getMessage());
        }
    }
    public void updateConta(int id, String novoNumeroConta, float novoSaldo, String novoTipo, int novaAgenciaId, String novaSenha) throws FalhaConexaoException {
        String sql = "UPDATE Conta SET numero_conta = ?, saldo = ?, tipo = ?, agencia_id = ?, senha = ? WHERE id = ?";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoNumeroConta);
            stmt.setFloat(2, novoSaldo);
            stmt.setString(3, novoTipo);
            stmt.setInt(4, novaAgenciaId);
            
            Conta conta = new Conta(id, novoNumeroConta ,novoSaldo, novoTipo, novaAgenciaId, novaSenha);
            stmt.setString(5, conta.hash(novaSenha));  
            
            stmt.setInt(6, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Nenhuma conta foi atualizada. Verifique se o id existe.");
            } else {
                System.out.println("Conta atualizada com sucesso.");
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao atualizar conta: " + e.getMessage());
        }
    }

    public void criarTabelaCliente() throws FalhaConexaoException {

        String sql = "CREATE TABLE IF NOT EXISTS Conta (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "numero_conta VARCHAR(20) NOT NULL," +
                    "saldo DECIMAL(10,2) DEFAULT 0.00," +
                    "tipo VARCHAR(20)," +
                    "agencia_id INT," +
                    "senha VARCHAR(256)," +
                    "FOREIGN KEY (agencia_id) REFERENCES Agencia(id_agencia) ON DELETE SET NULL ON UPDATE CASCADE" +
                    ");";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao criar tabela Conta: " + e.getMessage());
        }
    }
}