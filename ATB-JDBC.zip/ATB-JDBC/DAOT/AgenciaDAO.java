package DAOT;

/*import Bank.Agencia;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AgenciaDAO {
    public void inserirAgencia(Agencia agencia) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Agencia (id_agencia, endereco, telefone, codigo) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, agencia.getId_agencia());
                stmt.setString(2, agencia.getEndereco());
                stmt.setString(3, agencia.getTelefone());
                stmt.setString(4, agencia.getCodigo());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Agencia: " + e.getMessage());
        }
    }
}*/
