

import Bank.Agencia;
import Bank.Banco;
import Cliente.Cliente;
import Cliente.Conta;
import Conexao.FalhaConexaoException;
import DAOT.AgenciaDAO;
import DAOT.BancoDAO;
import DAOT.ClienteDAO;
import DAOT.ContaDAO;

public class Teste {
    public static void main(String[] args) {
        try {

            
            BancoDAO bancoDAO = new BancoDAO();
            AgenciaDAO agenciaDAO = new AgenciaDAO();
            ClienteDAO clienteDAO = new ClienteDAO();
            ContaDAO contaDAO = new ContaDAO();

            Banco banco = Banco.getInstancia(1, "Banco do Povo", "Av. Principal, 100", "1234-5678");
            bancoDAO.inserirBanco(banco);
            System.out.println("Banco criado: " + banco);

            Agencia agencia = new Agencia(0, "Rua Secundária, 200", "8765-4321", "AG123");
            agenciaDAO.inserirAgencia(agencia);
            System.out.println("Agência criada: " + agencia);

            Cliente cliente = new Cliente(0, "João Silva", "12345678900", "Rua Exemplo, 300", "9876-5432", "joao@email.com");
            clienteDAO.inserirCliente(cliente);
            System.out.println("Cliente criado: " + cliente);

            Conta conta = new Conta(0, "12345-6", 500.00f, "Corrente", agencia.getId_agencia(), "senha123");
            contaDAO.inserirConta(conta);
          
            System.out.println("Conexão fechada com sucesso!");

        } catch (FalhaConexaoException e) {
            System.err.println("Erro na conexão: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}






