package DAOT;

import Bank.Banco;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BancoDAO {
    
    public void inserirBanco(Banco banco) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Banco (id, nome, endereco, telefone) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, banco.getId_banco());
                stmt.setString(2, banco.getNome());
                stmt.setString(3, banco.getEndereco());
                stmt.setString(4, banco.getTelefone());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Banco: " + e.getMessage());
        }
    }

    public void criarTabelaBanco() throws FalhaConexaoException {
        String sql = "CREATE TABLE IF NOT EXISTS Banco (" +
                     "id_banco INT PRIMARY KEY AUTO_INCREMENT," +
                     "nome VARCHAR(100) NOT NULL," +
                     "endereco VARCHAR(150)," +
                     "telefone VARCHAR(15)" +
                     ");";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao criar tabela Banco: " + e.getMessage());
        }
    }

    public void updateBanco(int idBanco, String novoNome, String novoEndereco, String novoTelefone) throws FalhaConexaoException {
        String sql = "UPDATE Banco SET nome = ?, endereco = ?, telefone = ? WHERE id_banco = ?";
        try (Connection conexao = Conexao.obtemConexao();
            PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoNome);
            stmt.setString(2, novoEndereco);
            stmt.setString(3, novoTelefone);
            stmt.setInt(4, idBanco);
    
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Nenhum registro foi atualizado. Verifique se o id_banco existe.");
            } else {
                System.out.println("Banco atualizado com sucesso.");
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao atualizar banco: " + e.getMessage());
        }
    }

}
