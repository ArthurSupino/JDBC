package Bank;
import java.util.ArrayList;
import java.util.List;

public class Banco {
    private int id_banco;
    private String nome;
    private String endereco;
    private String telefone;
   

    private static Banco banco_unico;
    private List<Agencia> agencias = new ArrayList<>();

    private Banco(int id_banco, String nome, String endereco, String telefone) {
        this.id_banco = id_banco;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public static Banco getInstancia(int id_banco, String nome, String endereco, String telefone) {
        if (banco_unico == null) {
            banco_unico = new Banco(id_banco, nome, endereco, telefone);
        }
        return banco_unico;
    }

    public void adicionarAgencia(Agencia agencia) {
        this.agencias.add(agencia);
    }

    public void removerAgencia(Agencia agencia) {
        this.agencias.remove(agencia);
    }

    public List<Agencia> getAgencias() {
        return this.agencias;
    } 
    
    public int getId_banco() {
        return id_banco;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }
}


