package Bank.Streams;
import Bank.Agencia;
import Cliente.Cliente;
import Cliente.Conta;

import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class Streams 
{
    private List<Agencia> agencias;

    public Streams(List<Agencia> agencias) {
        this.agencias = agencias;
    }

    public List<Cliente> listarClientesComSaldoNegativo() {
        return agencias.stream()
                .flatMap(agencia -> agencia.getContas().stream())
                .flatMap(conta -> conta.getClientes().stream())
                .filter(cliente -> cliente.getContas().stream().anyMatch(c -> c.getSaldo() < 0))
                .distinct()
                .collect(Collectors.toList());
    }

    public OptionalDouble calcularMediaSaldoClientes() {
        return agencias.stream()
                .flatMap(agencia -> agencia.getContas().stream())
                .flatMap(conta -> conta.getClientes().stream())
                .flatMap(cliente -> cliente.getContas().stream())
                .mapToDouble(Conta::getSaldo)
                .average();
    }

    public List<Cliente> listarClientesComSaldoAcima(double valor) {
        return agencias.stream()
                .flatMap(agencia -> agencia.getContas().stream())
                .flatMap(conta -> conta.getClientes().stream())
                .filter(cliente -> cliente.getContas().stream().anyMatch(c -> c.getSaldo() > valor))
                .distinct()
                .collect(Collectors.toList());
    }

    public long contarClientes() {
        return agencias.stream()
                .flatMap(agencia -> agencia.getContas().stream())
                .flatMap(conta -> conta.getClientes().stream())
                .distinct()
                .count();
    }

    public List<Cliente> listarClientesPorNome() {
        return agencias.stream()
                .flatMap(agencia -> agencia.getContas().stream())
                .flatMap(conta -> conta.getClientes().stream())
                .distinct()
                .sorted((c1, c2) -> c1.getNome().compareTo(c2.getNome()))
                .collect(Collectors.toList());
    }
}
