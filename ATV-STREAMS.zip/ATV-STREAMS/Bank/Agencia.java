package Bank;
import java.util.ArrayList;
import java.util.List;
import Cliente.*;

public class Agencia {
    private int id_agencia;
    private String endereco;
    private String telefone;
    private String codigo;
    

    private List<Conta> contas = new ArrayList<>();

    public Agencia(int id, String endereco, String telefone, String codigo) {
        this.id_agencia = id;
        this.endereco = endereco;
        this.telefone = telefone;
        this.codigo = codigo;
        this.contas = new ArrayList<>();
    }

    public void adicionarConta(Conta conta) {
        this.contas.add(conta);
    }

    public void removerConta(Conta conta) {
        this.contas.remove(conta);
    }

    public List<Conta> getContas() {
        return this.contas;
    }
    
    public int getId_agencia() {
        return id_agencia;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCodigo() {
        return codigo;
    }
}

