import Bank.Agencia;
import Bank.Banco;
import Cliente.Cliente;
import Cliente.Conta;
import Bank.Streams.*;
import java.util.ArrayList;
import java.util.List;


public class TesteStreams {
    public static void main(String[] args) {

        Banco banco = Banco.getInstancia(1, "Banco do Povo", "Av. Principal, 100", "1234-5678");
        Agencia agencia1 = new Agencia(1, "Rua Secundária, 200", "8765-4321", "AG123");
        Agencia agencia2 = new Agencia(2, "Av. Terciária, 300", "5555-5555", "AG456");

        Cliente cliente1 = new Cliente(1, "João Silva", "12345678900", "Rua Exemplo, 300", "9876-5432", "joao@email.com");
        Cliente cliente2 = new Cliente(2, "Maria Oliveira", "98765432100", "Av. Central, 400", "1234-5678", "maria@email.com");
        
        Conta conta1 = new Conta(1, "12345-6", 500.00f, "Corrente", agencia1.getId_agencia(), "senha123");
        Conta conta2 = new Conta(2, "12345-7", -150.00f, "Poupança", agencia1.getId_agencia(), "senha456"); 
        Conta conta3 = new Conta(3, "12345-8", 700.00f, "Corrente", agencia2.getId_agencia(), "senha789");
        
        cliente1.adicionarConta(conta1);
        cliente1.adicionarConta(conta2);
        cliente2.adicionarConta(conta3);
        
        agencia1.adicionarConta(conta1);
        agencia1.adicionarConta(conta2);
        agencia2.adicionarConta(conta3);
        
        List<Agencia> agencias = new ArrayList<>();
        agencias.add(agencia1);
        agencias.add(agencia2);
        
        Streams bancoService = new Streams(agencias);

        System.out.println("Clientes com saldo negativo:");
        List<Cliente> clientesNegativos = bancoService.listarClientesComSaldoNegativo();
        clientesNegativos.forEach(cliente -> System.out.println(cliente.getNome()));

        System.out.println("\nMédia de saldo dos clientes:");
        bancoService.calcularMediaSaldoClientes().ifPresent(media -> System.out.println(media));

        System.out.println("\nClientes com saldo acima de 100:");
        List<Cliente> clientesAcima100 = bancoService.listarClientesComSaldoAcima(100);
        clientesAcima100.forEach(cliente -> System.out.println(cliente.getNome()));

        System.out.println("\nTotal de clientes: " + bancoService.contarClientes());

        System.out.println("\nClientes ordenados por nome:");
        List<Cliente> clientesOrdenados = bancoService.listarClientesPorNome();
        clientesOrdenados.forEach(cliente -> System.out.println(cliente.getNome()));
    }
    }

