package DAOT;

import Bank.Agencia;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AgenciaDAO {
    public void inserirAgencia(Agencia agencia) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Agencia (id, codigo, endereco, telefone) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, agencia.getId_agencia());
                stmt.setString(2, agencia.getCodigo());
                stmt.setString(3, agencia.getEndereco());
                stmt.setString(4, agencia.getTelefone());

               
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Agencia: " + e.getMessage());
        }
    }
    public void criarTabelaAgencia() throws FalhaConexaoException {
        String sql = "CREATE TABLE IF NOT EXISTS Agencia (\n" + 
                        "    id_agencia INT AUTO_INCREMENT PRIMARY KEY,\n" + 
                        "    endereco VARCHAR(150) NOT NULL,\n" + 
                        "    telefone VARCHAR(15),\n" + 
                        "    codigo VARCHAR(10) UNIQUE\n" + 
                        ");\n" + 
                        "";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao criar tabela Agencia: " + e.getMessage());
        }
    }
    
    public void updateAgencia(int idAgencia, String novoEndereco, String novoTelefone, String novoCodigo) throws FalhaConexaoException {
        String sql = "UPDATE Agencia SET endereco = ?, telefone = ?, codigo = ? WHERE id_agencia = ?";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoEndereco);
            stmt.setString(2, novoTelefone);
            stmt.setString(3, novoCodigo);
            stmt.setInt(4, idAgencia);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Nenhuma agência foi atualizada. Verifique se o id_agencia existe.");
            } else {
                System.out.println("Agência atualizada com sucesso.");
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao atualizar agência: " + e.getMessage());
        }
    }
}
