package DAOT;

import Cliente.Cliente;
import Conexao.Conexao;
import Conexao.FalhaConexaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ClienteDAO {
    public void inserirCliente(Cliente cliente) throws FalhaConexaoException {
        try (Connection conexao = Conexao.obtemConexao()) {
            String sql = "INSERT INTO Cliente (id, nome, cpf, endereco, telefone, email) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setInt(1, cliente.getId());
                stmt.setString(2, cliente.getNome());
                stmt.setString(3, cliente.getCpf());
                stmt.setString(4, cliente.getEndereco());
                stmt.setString(5, cliente.getTelefone());
                stmt.setString(6, cliente.getEmail());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao inserir Cliente: " + e.getMessage());
        }

    }
    public void updateCliente(int id, String novoNome, String novoCpf, String novoEndereco, String novoTelefone, String novoEmail) throws FalhaConexaoException {
        String sql = "UPDATE Cliente SET nome = ?, cpf = ?, endereco = ?, telefone = ?, email = ? WHERE id = ?";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoNome);
            stmt.setString(2, novoCpf);
            stmt.setString(3, novoEndereco);
            stmt.setString(4, novoTelefone);
            stmt.setString(5, novoEmail);
            stmt.setInt(6, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Nenhum cliente foi atualizado. Verifique se o id existe.");
            } else {
                System.out.println("Cliente atualizado com sucesso.");
            }
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao atualizar cliente: " + e.getMessage());
        }
    }

    public void criarTabelaCliente() throws FalhaConexaoException {

        String sql = "CREATE TABLE IF NOT EXISTS Cliente ( \n" +
                    "id INT AUTO_INCREMENT PRIMARY KEY,\n " +
                        "nome VARCHAR(100) NOT NULL, \n" +
                        "cpf VARCHAR(11) UNIQUE, \n" +
                       " endereco VARCHAR(150), \n" +
                        "telefone VARCHAR(15), \n" +
                        "email VARCHAR(100) \n" +
                        ");";
        try (Connection conexao = Conexao.obtemConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new FalhaConexaoException("Erro ao criar tabela Cliente: " + e.getMessage());
        }
    }
}

